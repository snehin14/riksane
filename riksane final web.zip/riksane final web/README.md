# RIKSANE PRODUCTION PRIVATE LIMITED – Full-Stack Website

## Project Structure

```
riksane/
├── server.js              # Express server entry point
├── package.json
├── .env.example           # Copy to .env and fill in values
│
├── routes/
│   ├── inquiry.js         # POST/GET /api/inquiry
│   ├── events.js          # CRUD   /api/events
│   └── gallery.js         # GET    /api/gallery
│
└── public/                # Static frontend (served by Express)
    ├── index.html         # Semantic HTML structure
    ├── style.css          # Design system + animations + responsive
    └── main.js            # Particles, reveals, API calls, form logic
```

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your real SMTP credentials

# 3. Run dev server
node server.js
# → http://localhost:3000
```

## API Routes

| Method | Route                  | Description                    |
|--------|------------------------|--------------------------------|
| POST   | /api/inquiry           | Submit a booking inquiry       |
| GET    | /api/inquiry           | List all inquiries (admin)     |
| GET    | /api/inquiry/:id       | Get single inquiry             |
| PATCH  | /api/inquiry/:id/status| Update status (new/contacted…) |
| GET    | /api/events            | List events (?status=upcoming) |
| POST   | /api/events            | Create new event               |
| DELETE | /api/events/:id        | Delete event                   |
| GET    | /api/gallery           | List gallery items (?category) |
| GET    | /api/health            | Health check                   |

## Features

### Frontend
- **Loader** – animated ring with wordmark on page load
- **Custom cursor** – gold ring with lag, expands on hover
- **Particle system** – canvas-based floating gold particles in hero
- **Scroll reveals** – IntersectionObserver fade-up/left/right
- **Counter animation** – animated stat numbers on scroll
- **Gallery filters** – client-side filter by category
- **Form validation** – client-side + server-side with live error states

### Backend
- Express + Helmet (security headers)
- Rate limiting (50 req / 15 min per IP)
- CORS
- Body parsing (JSON + URL-encoded)
- Structured REST API with proper HTTP status codes
- In-memory store (plug in MongoDB/MySQL via .env)

## Upgrading to a Real Database

In `routes/inquiry.js` and `routes/events.js`, replace the `inquiries[]` / `events[]` arrays with:

```js
// MongoDB example
const { MongoClient } = require('mongodb');
const client = new MongoClient(process.env.MONGO_URI);
const db = client.db('riksane');
const inquiriesCol = db.collection('inquiries');
```

## Enabling Email Notifications

In `routes/inquiry.js`, install and configure nodemailer:

```bash
npm install nodemailer
```

```js
const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});

await transporter.sendMail({
  from: process.env.SMTP_USER,
  to: process.env.NOTIFY_EMAIL,
  subject: `New Inquiry from ${name}`,
  text: `Name: ${name}\nEmail: ${email}\nMessage: ${message}`
});
```

## Deployment (Render / Railway / VPS)

1. Push to GitHub
2. Connect repo to Render / Railway
3. Set environment variables from `.env.example`
4. Build command: `npm install`
5. Start command: `node server.js`
