const express = require('express');
const router = express.Router();

/**
 * Seed data – replace with DB in production
 */
let events = [
  {
    id: '1',
    title: 'Grand Launch Night',
    type: 'Live Music',
    date: '2026-08-15',
    time: '07:00 PM',
    venue: 'TBD – Pune',
    description: 'Our first live music showcase featuring local artists and DJs.',
    capacity: 200,
    ticketsLeft: 200,
    price: 499,
    image: null,
    status: 'upcoming'
  },
  {
    id: '2',
    title: 'Corporate Gala Evening',
    type: 'Corporate Event',
    date: '2026-09-20',
    time: '06:30 PM',
    venue: 'Hotel Pride, Pune',
    description: 'Premium entertainment for corporate celebrations and product launches.',
    capacity: 150,
    ticketsLeft: 150,
    price: 0,
    image: null,
    status: 'upcoming'
  }
];

/**
 * GET /api/events
 * List events – optional ?type=Live Music&status=upcoming
 */
router.get('/', (req, res) => {
  let result = [...events];

  if (req.query.type) {
    result = result.filter(e => e.type.toLowerCase() === req.query.type.toLowerCase());
  }
  if (req.query.status) {
    result = result.filter(e => e.status === req.query.status);
  }

  res.json({ success: true, total: result.length, data: result });
});

/**
 * GET /api/events/:id
 */
router.get('/:id', (req, res) => {
  const event = events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ success: false, error: 'Event not found.' });
  res.json({ success: true, data: event });
});

/**
 * POST /api/events
 * Create a new event
 */
router.post('/', (req, res) => {
  const { title, type, date, time, venue, description, capacity, price } = req.body;

  if (!title || !date || !venue) {
    return res.status(400).json({ success: false, error: 'title, date, and venue are required.' });
  }

  const event = {
    id: Date.now().toString(),
    title: title.trim(),
    type: type?.trim() || 'General',
    date,
    time: time || 'TBD',
    venue: venue.trim(),
    description: description?.trim() || '',
    capacity: Number(capacity) || 100,
    ticketsLeft: Number(capacity) || 100,
    price: Number(price) || 0,
    image: null,
    status: 'upcoming',
    createdAt: new Date().toISOString()
  };

  events.push(event);
  res.status(201).json({ success: true, data: event });
});

/**
 * DELETE /api/events/:id
 */
router.delete('/:id', (req, res) => {
  const idx = events.findIndex(e => e.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'Event not found.' });
  events.splice(idx, 1);
  res.json({ success: true, message: 'Event deleted.' });
});

module.exports = router;
