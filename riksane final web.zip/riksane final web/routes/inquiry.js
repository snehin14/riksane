const express = require('express');
const router = express.Router();

/**
 * In-memory store (replace with MongoDB/MySQL in production)
 */
const inquiries = [];

/**
 * POST /api/inquiry
 * Submit a booking inquiry
 */
router.post('/', (req, res) => {
  const { name, email, phone, eventType, eventDate, message } = req.body;

  // Basic validation
  if (!name || !email || !message) {
    return res.status(400).json({ success: false, error: 'Name, email, and message are required.' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ success: false, error: 'Invalid email address.' });
  }

  const inquiry = {
    id: Date.now().toString(),
    name: name.trim(),
    email: email.trim().toLowerCase(),
    phone: phone?.trim() || null,
    eventType: eventType?.trim() || 'General Inquiry',
    eventDate: eventDate || null,
    message: message.trim(),
    status: 'new',
    createdAt: new Date().toISOString()
  };

  inquiries.push(inquiry);

  // TODO: plug in nodemailer here to send email notification
  // await sendMail({ to: 'riksaneproduction@gmail.com', subject: `New Inquiry from ${name}`, ... });

  console.log(`[Inquiry] New submission from ${name} <${email}>`);

  res.status(201).json({
    success: true,
    message: 'Your inquiry has been received! We will get back to you within 24 hours.',
    id: inquiry.id
  });
});

/**
 * GET /api/inquiry
 * List all inquiries (admin use – add auth middleware in production)
 */
router.get('/', (req, res) => {
  res.json({ success: true, total: inquiries.length, data: inquiries });
});

/**
 * GET /api/inquiry/:id
 */
router.get('/:id', (req, res) => {
  const inquiry = inquiries.find(i => i.id === req.params.id);
  if (!inquiry) return res.status(404).json({ success: false, error: 'Inquiry not found.' });
  res.json({ success: true, data: inquiry });
});

/**
 * PATCH /api/inquiry/:id/status
 * Update inquiry status (new → contacted → closed)
 */
router.patch('/:id/status', (req, res) => {
  const inquiry = inquiries.find(i => i.id === req.params.id);
  if (!inquiry) return res.status(404).json({ success: false, error: 'Inquiry not found.' });

  const allowed = ['new', 'contacted', 'closed'];
  if (!allowed.includes(req.body.status)) {
    return res.status(400).json({ success: false, error: `Status must be one of: ${allowed.join(', ')}` });
  }

  inquiry.status = req.body.status;
  inquiry.updatedAt = new Date().toISOString();

  res.json({ success: true, data: inquiry });
});

module.exports = router;
