const express = require('express');
const router = express.Router();

/**
 * Seed – replace with DB + cloud storage (S3/Cloudinary) in production
 */
const gallery = [
  { id: '1', title: 'Stage Setup', category: 'setup', url: null, placeholder: true },
  { id: '2', title: 'Lighting Rig', category: 'setup', url: null, placeholder: true },
  { id: '3', title: 'Performance Area', category: 'event', url: null, placeholder: true },
  { id: '4', title: 'Sound Console', category: 'setup', url: null, placeholder: true },
  { id: '5', title: 'Opening Night', category: 'event', url: null, placeholder: true },
  { id: '6', title: 'DJ Set', category: 'event', url: null, placeholder: true }
];

/**
 * GET /api/gallery
 * Optional ?category=setup|event
 */
router.get('/', (req, res) => {
  let result = [...gallery];
  if (req.query.category) {
    result = result.filter(g => g.category === req.query.category);
  }
  res.json({ success: true, total: result.length, data: result });
});

module.exports = router;
