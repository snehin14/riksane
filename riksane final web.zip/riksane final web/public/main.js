/* ══════════════════════════════════════════════════
   RIKSANE PRODUCTION – main.js
   Handles: loader, cursor, particles, scroll
   reveals, counter animation, events/gallery API,
   form submission, hamburger nav, back-to-top
   ══════════════════════════════════════════════════ */

'use strict';

/* ── API base URL (auto-detect) ──────────────────── */
const API_BASE = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
  ? `http://${window.location.host}/api`
  : '/api';

/* ════════════════════════════════════════════════════
   1. LOADER
   ═══════════════════════════════════════════════════ */
window.addEventListener('load', () => {
  const loader = document.getElementById('loader');
  setTimeout(() => {
    loader.classList.add('hidden');
    // kick off reveals after load
    observeReveal();
    animateCounters();
  }, 900);
});

/* ════════════════════════════════════════════════════
   2. CUSTOM CURSOR
   ═══════════════════════════════════════════════════ */
(function initCursor () {
  const cursor    = document.getElementById('cursor');
  const cursorDot = document.getElementById('cursorDot');
  if (!cursor || !cursorDot) return;

  let mx = 0, my = 0, cx = 0, cy = 0;
  let raf;

  document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });

  function tick () {
    cx += (mx - cx) * 0.14;
    cy += (my - cy) * 0.14;
    cursor.style.left    = cx + 'px';
    cursor.style.top     = cy + 'px';
    cursorDot.style.left = mx + 'px';
    cursorDot.style.top  = my + 'px';
    raf = requestAnimationFrame(tick);
  }
  tick();

  // hover state on interactive elements
  document.querySelectorAll('a, button, .service-card, .gallery-item, .filter-btn').forEach(el => {
    el.addEventListener('mouseenter', () => cursor.classList.add('hover'));
    el.addEventListener('mouseleave', () => cursor.classList.remove('hover'));
  });
})();

/* ════════════════════════════════════════════════════
   3. PARTICLE SYSTEM (Hero background)
   ═══════════════════════════════════════════════════ */
(function initParticles () {
  const container = document.getElementById('particles');
  if (!container) return;

  const canvas = document.createElement('canvas');
  canvas.id = 'particleCanvas';
  container.appendChild(canvas);

  const ctx    = canvas.getContext('2d');
  const N      = 55;
  const GOLD   = 'rgba(212,175,55,';
  let   W, H, particles = [];

  function resize () {
    W = canvas.width  = container.offsetWidth;
    H = canvas.height = container.offsetHeight;
  }

  function rand (min, max) { return Math.random() * (max - min) + min; }

  function createParticle () {
    return {
      x:  rand(0, W), y:  rand(0, H),
      vx: rand(-.18, .18), vy: rand(-.25, -.05),
      r:  rand(.8, 2.4),
      a:  rand(0.15, 0.55), life: rand(60, 160), age: 0
    };
  }

  function draw () {
    ctx.clearRect(0, 0, W, H);
    particles.forEach((p, i) => {
      p.x += p.vx; p.y += p.vy; p.age++;
      const progress = p.age / p.life;
      const alpha    = p.a * (progress < .2 ? progress / .2 : 1 - (progress - .2) / .8);

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = GOLD + Math.max(0, alpha).toFixed(2) + ')';
      ctx.fill();

      if (p.age >= p.life) particles[i] = createParticle();
    });
    requestAnimationFrame(draw);
  }

  resize();
  window.addEventListener('resize', resize);
  for (let i = 0; i < N; i++) {
    const p = createParticle();
    p.age = Math.floor(Math.random() * p.life); // stagger starts
    particles.push(p);
  }
  draw();
})();

/* ════════════════════════════════════════════════════
   4. SCROLL REVEAL
   ═══════════════════════════════════════════════════ */
function observeReveal () {
  const targets = document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right');
  const obs     = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); }
    });
  }, { threshold: 0.15 });

  targets.forEach(t => obs.observe(t));

  // stagger service cards
  document.querySelectorAll('.service-card').forEach((card, i) => {
    card.style.transitionDelay = (i * 0.08) + 's';
    obs.observe(card);
  });
}

/* ════════════════════════════════════════════════════
   5. COUNTER ANIMATION
   ═══════════════════════════════════════════════════ */
function animateCounters () {
  const nums = document.querySelectorAll('.stat-num');
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el      = e.target;
      const target  = +el.dataset.count;
      const dur     = 1600;
      const start   = performance.now();
      function step (now) {
        const t = Math.min((now - start) / dur, 1);
        const eased = 1 - Math.pow(1 - t, 3); // ease-out-cubic
        el.textContent = Math.round(eased * target);
        if (t < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
      obs.unobserve(el);
    });
  }, { threshold: 0.5 });
  nums.forEach(n => obs.observe(n));
}

/* ════════════════════════════════════════════════════
   6. STICKY HEADER SHADOW
   ═══════════════════════════════════════════════════ */
const header = document.getElementById('header');
window.addEventListener('scroll', () => {
  header.style.background = window.scrollY > 60
    ? 'rgba(10,10,10,.97)'
    : 'rgba(10,10,10,.85)';
}, { passive: true });

/* ════════════════════════════════════════════════════
   7. HAMBURGER MENU
   ═══════════════════════════════════════════════════ */
(function initHamburger () {
  const btn       = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobileNav');
  if (!btn || !mobileNav) return;

  function toggle (open) {
    btn.classList.toggle('open', open);
    mobileNav.classList.toggle('open', open);
    btn.setAttribute('aria-expanded', String(open));
    mobileNav.setAttribute('aria-hidden', String(!open));
  }

  btn.addEventListener('click', () => toggle(!btn.classList.contains('open')));

  mobileNav.querySelectorAll('.mobile-link').forEach(link => {
    link.addEventListener('click', () => toggle(false));
  });
})();

/* ════════════════════════════════════════════════════
   8. BACK TO TOP
   ═══════════════════════════════════════════════════ */
(function initBackTop () {
  const btn = document.getElementById('backTop');
  if (!btn) return;
  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });
  btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
})();

/* ════════════════════════════════════════════════════
   9. LOAD EVENTS from API
   ═══════════════════════════════════════════════════ */
async function loadEvents () {
  const grid = document.getElementById('eventsGrid');
  if (!grid) return;

  try {
    const res  = await fetch(`${API_BASE}/events?status=upcoming`);
    const data = await res.json();

    if (!data.success || !data.data.length) {
      grid.innerHTML = '<p class="events-loading">No upcoming events announced yet. Check back soon!</p>';
      return;
    }

    grid.innerHTML = data.data.map(e => `
      <article class="event-card reveal-up">
        <div class="event-body">
          <span class="event-badge upcoming">${e.type}</span>
          <h3 style="margin-top:12px;font-size:22px">${e.title}</h3>
          <div class="event-meta">
            <span>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
              ${formatDate(e.date)}
            </span>
            <span>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              ${e.time}
            </span>
            <span>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              ${e.venue}
            </span>
          </div>
          <p class="event-desc">${e.description}</p>
          <div class="event-footer">
            <div class="event-price ${e.price === 0 ? 'free' : ''}">
              ${e.price === 0 ? 'Free Entry' : '₹' + e.price.toLocaleString('en-IN')}
              <small>${e.price === 0 ? 'Open to all' : 'per person'}</small>
            </div>
            <a href="#contact" class="btn btn-primary" style="font-size:13px;padding:9px 16px">Inquire</a>
          </div>
        </div>
      </article>
    `).join('');

    // re-run observer for new cards
    grid.querySelectorAll('.reveal-up').forEach((el, i) => {
      el.style.transitionDelay = (i * 0.1) + 's';
    });
    observeReveal();

  } catch {
    grid.innerHTML = '<p class="events-loading">Could not load events. Please refresh or contact us directly.</p>';
  }
}

function formatDate (dateStr) {
  if (!dateStr) return 'TBD';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
}

/* ════════════════════════════════════════════════════
   10. LOAD GALLERY from API
   ═══════════════════════════════════════════════════ */
let allGalleryItems = [];

async function loadGallery () {
  const grid = document.getElementById('galleryGrid');
  if (!grid) return;

  try {
    const res  = await fetch(`${API_BASE}/gallery`);
    const data = await res.json();

    allGalleryItems = data.data || [];
    renderGallery('all');

  } catch {
    grid.innerHTML = '<p class="events-loading">Gallery loading…</p>';
  }
}

function renderGallery (filter) {
  const grid = document.getElementById('galleryGrid');
  if (!grid) return;

  const items = filter === 'all' ? allGalleryItems : allGalleryItems.filter(g => g.category === filter);

  grid.innerHTML = items.map(g => `
    <div class="gallery-item reveal-up" data-category="${g.category}">
      ${g.url
        ? `<img src="${g.url}" alt="${g.title}" loading="lazy" style="width:100%;height:100%;object-fit:cover;"/>`
        : `<div class="gallery-placeholder">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
            <span>${g.title}</span>
            <small>${g.category}</small>
          </div>`
      }
    </div>
  `).join('');

  observeReveal();
}

// Gallery filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderGallery(btn.dataset.filter);
  });
});

/* ════════════════════════════════════════════════════
   11. INQUIRY FORM
   ═══════════════════════════════════════════════════ */
(function initForm () {
  const form       = document.getElementById('inquiryForm');
  const submitBtn  = document.getElementById('submitBtn');
  const successMsg = document.getElementById('formSuccess');
  if (!form) return;

  function clearErrors () {
    form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
    ['nameErr', 'emailErr', 'msgErr'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = '';
    });
  }

  function showError (fieldId, errId, msg) {
    const field = document.getElementById(fieldId);
    const err   = document.getElementById(errId);
    if (field) field.classList.add('error');
    if (err)   err.textContent = msg;
  }

  function validate (data) {
    let ok = true;
    if (!data.name.trim()) { showError('name', 'nameErr', 'Name is required.'); ok = false; }
    if (!data.email.trim()) { showError('email', 'emailErr', 'Email is required.'); ok = false; }
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) { showError('email', 'emailErr', 'Enter a valid email.'); ok = false; }
    if (!data.message.trim()) { showError('message', 'msgErr', 'Please tell us about your event.'); ok = false; }
    return ok;
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    clearErrors();
    successMsg.classList.remove('visible');

    const fd = new FormData(form);
    const data = {
      name:      fd.get('name'),
      email:     fd.get('email'),
      phone:     fd.get('phone'),
      eventType: fd.get('eventType'),
      eventDate: fd.get('eventDate'),
      message:   fd.get('message')
    };

    if (!validate(data)) return;

    submitBtn.classList.add('loading');
    submitBtn.disabled = true;

    try {
      const res   = await fetch(`${API_BASE}/inquiry`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await res.json();

      if (result.success) {
        form.reset();
        successMsg.textContent = result.message;
        successMsg.classList.add('visible');
        successMsg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } else {
        throw new Error(result.error || 'Submission failed.');
      }
    } catch (err) {
      successMsg.textContent = err.message || 'Something went wrong. Please email us directly.';
      successMsg.style.background = 'rgba(169,36,19,.1)';
      successMsg.style.borderColor = 'rgba(169,36,19,.3)';
      successMsg.style.color = '#e05c4a';
      successMsg.classList.add('visible');
    } finally {
      submitBtn.classList.remove('loading');
      submitBtn.disabled = false;
    }
  });

  // live validation on blur
  form.querySelectorAll('input, textarea').forEach(el => {
    el.addEventListener('blur', () => {
      if (el.required && !el.value.trim()) el.classList.add('error');
      else el.classList.remove('error');
    });
  });
})();

/* ════════════════════════════════════════════════════
   12. SMOOTH ANCHOR SCROLLING (offset for fixed header)
   ═══════════════════════════════════════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const target = document.querySelector(link.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const offset = 76;
    const top    = target.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

/* ── INIT ────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  loadEvents();
  loadGallery();
});
